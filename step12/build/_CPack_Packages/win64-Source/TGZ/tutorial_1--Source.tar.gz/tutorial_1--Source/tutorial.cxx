#include<iostream>
#include<cstdlib>
#include "tutorial.h"

int main(char argc, char* argv[]) {
    // const double inputVar = std::stod(argv[1]);
    // std::cout<<inputVar<<std::endl;
    std::cout<<"Hello World"<<std::endl;
    if (argc<2) {
        // std::cout<<argv[0]<<" Version "<<Tutorial_VERSION_MAJOR<<"."<<Tutorial_VERSION_MINOR<<std::endl;
    }
    return 0;
}
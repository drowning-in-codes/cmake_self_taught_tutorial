#include<iostream>

int main(void) {
    std::cout<<"Hello"<<std::endl;
    return 0;
}